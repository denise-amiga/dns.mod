/*
 * Simplified BSD License
 *
 * Copyright (c) 1992-2019, Eligis
 * All rights reserved.
 *
 * Redistribution and  use in  source and binary  forms, with  or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * o Redistributions  of  source  code must  retain  the  above copyright
 *   notice, this list of conditions and the following disclaimer.
 * o Redistributions  in  binary form  must reproduce the above copyright
 *   notice, this list of conditions and  the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
 * "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES (INCLUDING,  BUT  NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING  IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file hextable.c
 * @brief Hexadecimal table code generator.
 * @version 10.5.0
 * @author C. Jullien
 * @copyright Eligis, 1988-2019
 * $Revision: 1.10 $
 * $Date: 2018/12/21 06:28:14 $
 */

#include <stdio.h>
#include <ctype.h>

#define ASCII_A         ((char)0x61)

int
main(int argc, char *argv[]) {
        const char *letter = "abcdefghijklmnopqrstuvwxyz";
        const char *digit  = "0123456789";
        const char *s;

        int     i;
        int     size;
        char *  tab;

        if (*letter == ASCII_A) {
                size = 128;
        } else {
                size = 256;
        }

        tab = (char *)malloc(size);

        for (i = 0; i < size; ++i) {
                tab[i] = 0;
        }
                
        i = 0;

        for (s = digit; *s != 0; ++s) {
                tab[(int)*s] = i++;
        }

        for (s = letter; *s != 0; ++s) {
                tab[(int)*s] = i;
                tab[(int)toupper(*s)] = i++;
        }

        if (size == 128) {
                (void)printf("/*\n");
                (void)printf(" * ANSI character class table\n");
                (void)printf(" */\n");
        } else {
                (void)printf("/*\n");
                (void)printf(" * EBCDIC character class table\n");
                (void)printf(" */\n");
        }

        (void)printf("static const BigNumDigit BigHexToDigit[] = {");

        for (i = 0; i < size; i++) {
                if ((i % 16) == 0) {
                        printf("\n\t");
                }
                (void)printf("%2d%c ", tab[i], ((i < (size-1)) ? ',' : ' '));
        }

        (void)printf("\n};\n\n");

        (void)printf("#define\tCTOI(c)\t((((unsigned int)c)<(unsigned int)%d)",
                      size - 1);
        (void)printf("\t\\\n\t\t ? BigHexToDigit[(unsigned int)c]");
        (void)printf("\t\\\n\t\t : 0)\n");

        free(tab);

        return 0;
}
