/*
 * Simplified BSD License
 *
 * Copyright (c) 1992-2019, Eligis
 * All rights reserved.
 *
 * Redistribution and  use in  source and binary  forms, with  or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * o Redistributions  of  source  code must  retain  the  above copyright
 *   notice, this list of conditions and the following disclaimer.
 * o Redistributions  in  binary form  must reproduce the above copyright
 *   notice, this list of conditions and  the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
 * "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES (INCLUDING,  BUT  NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING  IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file testbits.c
 * @brief Internal testing tool.
 * @version 10.5.0
 * @author C. Jullien
 * @copyright Eligis, 1988-2019
 * $Revision: 1.8 $
 * $Date: 2018/12/21 06:28:14 $
 */

/*
 *      testbits.c :    
 */

#include <stdio.h>

void
showbits(unsigned int n)
{
        int     j = 1;
        int     i;

        printf("%16d %08x -> ", n, n);

        for (i = 31; i >= 0; i--) {
                printf("%d", (n & (1 << i)) ? 1 : 0);
        }
}

int
main(int argc, char *argv[]) {
        int x = -45967;
        int y = -3;

        printf("x = %lx, y = %lx, x >> y = %lx\n", x, y, x >> y);

        printf("\n");
        showbits(x);
        printf("\n");
        showbits(~x);
        printf("\n");

        return 0;
}
