//
// $Id: CRational.h,v 1.44 2018/12/23 08:52:07 jullien Exp $
//

/*
 * Simplified BSD License
 *
 * Copyright (c) 1988-2019, Eligis
 * All rights reserved.
 *
 * Redistribution and  use in  source and binary  forms, with  or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * o Redistributions  of  source  code must  retain  the  above copyright
 *   notice, this list of conditions and the following disclaimer.
 * o Redistributions  in  binary form  must reproduce the above copyright
 *   notice, this list of conditions and  the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 * 
 * THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
 * "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES (INCLUDING,  BUT  NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING  IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file CRational.h
 * @brief C++ wrapper on bigq C API.
 * @version 1.6.3
 * @copyright Eligis, 1988-2019
 * @author C. Jullien
 * $Revision: 1.44 $
 * $Date: 2018/12/23 08:52:07 $
 */

#if !defined(__CRATIONAL_H)
#define __CRATIONAL_H

#include <stdlib.h>
#include <ostream>
#include <bigq.h>
#include <string>
#include "CBignum.h"

namespace rational {

using bignum::CBignum;

/**
 * Bignum rational class.
 */
class CRational {
 public:
  /**
   * ctor from CBignum.
   * @param [in] n CBignum.
   */
  explicit CRational(const CBignum& n = 0)
    : m_q{BqCreate(n, bignum::one)} {
  }

  /**
   * ctor from two CBignums.
   * @param [in] n numerator.
   * @param [in] d denominator.
   */
  CRational(const CBignum& n, const CBignum& d)
    : m_q{BqCreate(n, d)} {
  }
#if 0
  explicit CRational(int n)
    : m_q{BqCreate(CBignum(n), bignum::one)}) {
  }
#endif
  /**
   * copy-ctor.
   * @param [in] q CRational.
   */
  CRational(const CRational& q)
    : m_q{BqCreate(BqGetNumerator(q.m_q), BqGetDenominator(q.m_q))} {
  }

  /**
   * move-ctor.
   * @param [in] rhs CRational.
   */
  CRational(CRational&& rhs)
    : m_q{rhs.m_q} {
    rhs.m_q = nullptr;
  }

  /**
   * ctor from C string.
   * @param [in] s C string.
   */
  explicit CRational(const char* s)
    : m_q{BqFromString(static_cast<const BzChar *>(s), 10)} {
  }
#if defined(HAVE_BQ_FROM_DOUBLE)
  explicit CRational(double n)
    : m_q{BqFromDouble(n)} {
  }
#endif
  /**
   * dtor.
   */
  ~CRational() {
    if (m_q) {
      BqDelete(m_q);
    }
  }

  /**
   * convert CRational to closest CBignum.
   * @return CBignum.
   */
  operator CBignum() const noexcept {
    return numerator() / denominator();
  }

 /**
  * @return numerator of CRational object.
  */
  const CBignum numerator() const {
    return BqGetNumerator(m_q);
  }

 /**
  * @param [in] q CRational.
  * @return numerator of CRational argument.
  */
  friend CBignum numerator(const CRational& q) {
    return q.numerator();
  }

 /**
  * @return denominator of CRational object.
  */
  const CBignum denominator() const {
    return BqGetDenominator(m_q);
  }

 /**
  * @param [in] q CRational.
  * @return denominator of CRational argument.
  */
  friend CBignum denominator(const CRational& q) {
    return q.denominator();
  }

  /**
   * @param [in] rhs CRational object to be assigned from.
   * @return *this.
   */
  CRational& operator=(const CRational& rhs) {
    BqDelete(m_q);
    m_q = BqCreate(rhs.numerator(), rhs.denominator());
    return *this;
  }

  /**
   * @param [in] rhs CRational object to be move-assigned from.
   * @return *this.
   */
  CRational& operator=(CRational&& rhs) {
    BqDelete(m_q);
    m_q = rhs.m_q;
    rhs.m_q = nullptr;
    return *this;
  }

  // convertions

  /**
   * automatic double conversion.
   * @return object as double.
   */
  operator double () const noexcept {
    return BqToDouble(m_q);
  }

  /**
   * automatic string conversion.
   * @return object as std::string.
   */
  operator std::string () const noexcept;

  // unary -

  /**
   * Negate argument.
   * @return CRational.
   */
  friend CRational operator-(const CRational& q) {
    return CRational{BqNegate(q.m_q), Flags::ASSIGN};
  }

  // unary ++, --

  /**
   * Pre-increment operator.
   * @return *this.
   */
  inline CRational& operator++();
  /**
   * Post-increment operator.
   * @return a copy of *this.
   */
  CRational operator++(int);
  /**
   * Pre-decrement operator.
   * @return *this.
   */
  inline CRational& operator--();
  /**
   * Post-decrement operator.
   * @return a copy of *this.
   */
  CRational operator--(int);

  /**
   * Binary +
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return a new CRational.
   */
  friend CRational operator+(const CRational& q1, const CRational& q2) {
    return CRational{BqAdd(q1.m_q, q2.m_q), Flags::ASSIGN};
  }

  /**
   * Binary -
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return a new CRational.
   */
  friend CRational operator-(const CRational& q1, const CRational& q2) {
    return CRational{BqSubtract(q1.m_q, q2.m_q), Flags::ASSIGN};
  }

  /**
   * Binary *
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return a new CRational.
   */
  friend CRational operator*(const CRational& q1, const CRational& q2) {
    return CRational{BqMultiply(q1.m_q, q2.m_q), Flags::ASSIGN};
  }

  /**
   * Binary /
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return a new CRational.
   */
  friend CRational operator/(const CRational& q1, const CRational& q2) {
    return CRational{BqDiv(q1.m_q, q2.m_q), Flags::ASSIGN};
  }

  // comparisons

  /**
   * Compare two CRational with ==
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return bool.
   */
  friend bool operator==(const CRational& q1, const CRational& q2) {
    return BqCompare(q1.m_q, q2.m_q) == BQ_EQ;
  }

  /**
   * Compare a CRational and a non-rational number with ==
   * @param [in] q left side.
   * @param [in] n right side convertible to a CRational.
   * @return bool.
   * @tparam T type convertible to a CRational.
   */
  template<
    typename T,
    typename std::enable_if<std::is_convertible<T,CRational>::value>::type*
      = nullptr>
  friend bool operator==(const CRational& q, const T& n) {
    return (q == CRational{n});
  }

  /**
   * Compare a non-rational number and a CRational with ==
   * @param [in] n left side convertible to a CRational.
   * @param [in] q rigth side.
   * @return bool.
   * @tparam T type convertible to a CRational.
   */
  template<
    typename T,
    typename std::enable_if<std::is_convertible<T,CRational>::value>::type*
      = nullptr>
  friend bool operator==(const T& n, const CRational& q) {
    return (CRational{n} == q);
  }

  /**
   * Compare two CRational with !=
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return bool.
   */
  friend bool operator!=(const CRational& q1, const CRational& q2) {
    return !(q1 == q2);
  }

  /**
   * Compare two CRational with \>
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return bool.
   */
  friend bool operator>(const CRational& q1, const CRational& q2) {
    return BqCompare(q1.m_q, q2.m_q) == BQ_GT;
  }

  /**
   * Compare a CRational and a non-rational number with \>
   * @param [in] q left side.
   * @param [in] n right side convertible to a CRational.
   * @return bool. 
   * @tparam T type convertible to a CRational.
   */
  template<
    typename T,
    typename std::enable_if<std::is_convertible<T,CRational>::value>::type*
      = nullptr>
  friend bool operator>(const CRational& q, const T& n) {
    return (q > CRational{n});
  }

  /**
   * Compare a non-rational number and a CRational with >
   * @param [in] n left side convertible to a CRational.
   * @param [in] q rigth side.
   * @return bool.
   * @tparam T type convertible to a CRational.
   */
  template<
    typename T,
    typename std::enable_if<std::is_convertible<T,CRational>::value>::type*
      = nullptr>
  friend bool operator>(const T& n, const CRational& q) {
    return (CRational{n} > q);
  }

  /**
   * Compare two CRational with \<=
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return bool.
   */
  friend bool operator<=(const CRational& q1, const CRational& q2) {
    return !(q1 > q2);
  }

  /**
   * Compare two CRational with \<
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return bool.
   */
  friend bool operator<(const CRational& q1, const CRational& q2) {
    return BqCompare(q1.m_q, q2.m_q) == BQ_LT;
  }

  /**
   * Compare a CRational and a non-rational number with \<
   * @param [in] q left side.
   * @param [in] n right side convertible to a CRational.
   * @return bool.
   * @tparam T type convertible to a CRational.
   */
  template<
    typename T,
    typename std::enable_if<std::is_convertible<T,CRational>::value>::type*
      = nullptr>
  friend bool operator<(const CRational& q, const T& n) {
    return (q < CRational{n});
  }

  /**
   * Compare a non-rational number and a CRational with \<
   * @param [in] n left side convertible to a CRational.
   * @param [in] q rigth side.
   * @return bool.
   * @tparam T type convertible to a CRational.
   */
  template<
    typename T,
    typename std::enable_if<std::is_convertible<T,CRational>::value>::type*
      = nullptr>
  friend bool operator<(const T& n, const CRational& q) {
    return (CRational{n} < q);
  }

  /**
   * Compare two CRational with \>=
   * @param [in] q1 left side.
   * @param [in] q2 right side.
   * @return bool.
   */
  friend bool operator>=(const CRational& q1, const CRational& q2) {
    return !(q1 < q2);
  }

  /**
   * Get absolute value of CRational.
   * @param [in] q CRational.
   * @return CRational.
   */
  friend CRational abs(const CRational& q) {
    return CRational{BqAbs(q.m_q), Flags::ASSIGN};
  }

  /**
   * Get inverse value of CRational.
   * @param [in] q CRational.
   * @return CRational.
   */
  friend CRational inverse(const CRational& q) {
    return CRational{BqInverse(q.m_q), Flags::ASSIGN};
  }

  /**
   * output q to output stream os.
   * @param [in] os output stream.
   * @param [in] q CRational.
   * @return os.
   */
  friend std::ostream& operator<<(std::ostream& os, const CRational& q);

 private:
  enum class Flags { ASSIGN };
  BigQ m_q{nullptr};
  CRational(const BigQ init, Flags) : m_q{init} {}
};

inline CRational&
CRational::operator++() {
  *this = *this + CRational{bignum::one};
  return *this;
}

inline CRational&
CRational::operator--() {
  *this = *this - CRational{bignum::one};
  return *this;
}
} /* namespace rational */
/**
 * user- defined rational literals from string.
 * @param [in] init initial litteral string that represent a CRational.
 */
static inline rational::CRational operator"" _br(const char* init, size_t) {
  return rational::CRational(init);
}

/**
 * user- defined rational literals from unsigned long.
 * @param [in] init initial litteral string that represent a CRational.
 */
static inline rational::CRational operator"" _br(unsigned long long init) {
  return rational::CRational{init};
}
#if defined(HAVE_BQ_FROM_DOUBLE)
/**
 * user- defined rational literals from double.
 * @param [in] init initial litteral string that represent a CRational.
 */
static inline rational::CRational operator"" _br(long double init) {
  return rational::CRational{init};
}
#endif
#endif  /* __CRATIONAL_H */
