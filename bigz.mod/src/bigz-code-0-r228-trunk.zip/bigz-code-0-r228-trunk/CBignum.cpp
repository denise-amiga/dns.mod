/*
 * Simplified BSD License
 *
 * Copyright (c) 1988-1989, Digital Equipment Corporation & INRIA.
 * Copyright (c) 1988-2019, Eligis
 * All rights reserved.
 *
 * Redistribution and  use in  source and binary  forms, with  or without
 * modification, are permitted provided that the following conditions are
 * met:
 *
 * o Redistributions  of  source  code must  retain  the  above copyright
 *   notice, this list of conditions and the following disclaimer.
 * o Redistributions  in  binary form  must reproduce the above copyright
 *   notice, this list of conditions and  the following disclaimer in the
 *   documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE  IS PROVIDED BY  THE COPYRIGHT HOLDERS  AND CONTRIBUTORS
 * "AS  IS" AND  ANY EXPRESS  OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT
 * LIMITED TO, THE IMPLIED  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE  ARE DISCLAIMED. IN NO EVENT  SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL,  EXEMPLARY,  OR  CONSEQUENTIAL  DAMAGES (INCLUDING,  BUT  NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE  GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS  INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF  LIABILITY, WHETHER IN  CONTRACT, STRICT LIABILITY,  OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING  IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 * $Id: CBignum.cpp,v 1.31 2018/12/23 08:52:07 jullien Exp $
 */

#include <string.h>
#include <stdio.h>
#include <string>
#include <ostream>
#include <iomanip>
#include "CBignum.h"

namespace bignum {

extern const CBignum zero(0);
extern const CBignum one(1);
extern const CBignum two(2);
extern const CBignum ten(10);

CBignum
CBignum::pow(const CBignum& exp) const {
  BzInt i{BzToInteger(exp.m_bz)};
  if (i > 0) {
    return CBignum{BzPow(m_bz, i), Flags::ASSIGN};
  } else if (i == 0) {
    return one;
  } else {
    throw std::domain_error("pow is passed a negative argument " +
                            static_cast<std::string>(exp));
  }
}

CBignum::operator std::string () const throw() {
  size_t len{0};
  const BzChar* s{BzToStringBufferExt(m_bz, 10, 0, 0, 0, &len)};
  std::string res(s, len);
  BzFreeString(const_cast<BzChar*>(s));
  return res;
}

std::ostream& operator<<(std::ostream& os, const CBignum& bn) {
  static constexpr size_t iosShowBase{static_cast<size_t>(std::ios::showbase)};
  static constexpr size_t iosLeft{static_cast<size_t>(std::ios::left)};
  static constexpr size_t iosHex{static_cast<size_t>(std::ios::hex)};
  static constexpr size_t iosOct{static_cast<size_t>(std::ios::oct)};
  static constexpr size_t iosShowpos{static_cast<size_t>(std::ios::showpos)};

  const BzChar* res{nullptr};
  const auto ioflags(os.flags());
  auto width(static_cast<size_t>(os.width()));
  bool showBase = !!(static_cast<size_t>(ioflags) & iosShowBase);
  size_t len;
  os << std::setw(0);

  if (static_cast<size_t>(ioflags) & iosHex) {
    // hexadecimal output
    res = BzToStringBufferExt(bn.m_bz, 16, 0, 0, 0, &len);
    if (showBase) {
     len += 2;  // '0x' prefix
    }
    if ((len < width) && !(static_cast<size_t>(ioflags) & iosLeft)) {
     const std::string pad(width - len, os.fill());
     os << pad;
    }
    if (res[0] == '-') {
      os << "-";
    }
    if (showBase) {
      os << "0x";
    }
    if (res[0] == '-') {
      os << &res[1];
    } else {
      os << res;
    }
    if ((len < width) && (static_cast<size_t>(ioflags) & iosLeft)) {
      const std::string pad(width - len, os.fill());
      os << pad;
    }
  } else if (static_cast<size_t>(ioflags) & iosOct) {
    // octal output
    res = BzToStringBufferExt(bn.m_bz, 8, 0, 0, 0, &len);
    if (showBase) {
     len += 1; // '0' prefix
    }
    if ((len < width) && !(static_cast<size_t>(ioflags) & iosLeft)) {
      const std::string pad(width - len, os.fill());
      os << pad;
    }
    if (res[0] == '-') {
      os << "-";
    }
    if (showBase) {
      os << "0";
    }
    if (res[0] == '-') {
      os << &res[1];
    } else {
      os << res;
    }
    if ((len < width) && (static_cast<size_t>(ioflags) & iosLeft)) {
      const std::string pad(width - len, os.fill());
      os << pad;
    }
  } else {
    // decimal output
    if (static_cast<size_t>(ioflags) & iosShowpos) {
      res = BzToStringBufferExt(bn.m_bz, 10, BZ_FORCE_SIGN, 0, 0, &len);
    } else {
      res = BzToStringBufferExt(bn.m_bz, 10, 0, 0, 0, &len);
    }
      
    if (len < width) {
      const std::string pad(width - len, os.fill());
      if (!(static_cast<size_t>(ioflags) & iosLeft)) {
        os << pad << res;
      } else {
        os << res << pad;
      }
    } else {
      os << res;
    }
  }
  BzFreeString(const_cast<BzChar*>(res));
  os.flags(ioflags);
  return os;
}

CBignum::CBignum(unsigned int bitLength, unsigned int* seed)
 : m_bz(nullptr) {
 CBignum init(one << (bitLength - 1));
  m_bz = BzRandom(init.m_bz, reinterpret_cast<BzSeed*>(seed));
}

CBignum
CBignum::operator++(int) {
  CBignum bn(*this);
  *this += one;
  return bn;
}

CBignum
CBignum::operator--(int) {
  CBignum bn(*this);
  *this -= one;
  return bn;
}
} /* namespace bignum */
